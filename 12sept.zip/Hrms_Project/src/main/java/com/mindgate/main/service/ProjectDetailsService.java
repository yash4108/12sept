
package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.domain.ProjectDetails;
import com.mindgate.main.repository.LoginDetailsRepositoryInterface;
import com.mindgate.main.repository.ProjectDetailsRepositoryInterface;

@Service
public class ProjectDetailsService implements ProjectDetailsServiceInterface {

  @Autowired
	private ProjectDetailsRepositoryInterface ProjectDetailsRepository;

	@Override
	public List<ProjectDetails> viewBudget(int projectId) {
		// TODO Auto-generated method stub
		return ProjectDetailsRepository.viewBudget(projectId);
	}

}