package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.domain.ProjectDetails;
@Repository
public class EmployeeDetailsRepository implements EmployeeDetailsRepositoryInterface{

	private final static String GET_EMPLOYEE_BY_LOGIN_ID ="SELECT * FROM EMPLOYEE_DETAILS WHERE LOGIN_ID=?";
	private final static String CHECK_EMPLOYEE_LIST="select * from employee_details where project_id = 103 and skill_1 = (select skill_1 from job_description_details where job_id =?) and skill_2 = (select skill_2 from job_description_details where job_id = ?) and skill_3 = (select skill_3 from job_description_details where job_id =?)";
	private final static String UPDATE_PROJECT_ID_BY_EMPLOYEE_ID="update Employee_details SET project_Id=?,mgr=?,status=? where employee_id=?";
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public EmployeeDetails getEmployeeByLoginId(int loginId) {
		EmployeeDetails employeeDetails=jdbcTemplate.queryForObject(GET_EMPLOYEE_BY_LOGIN_ID, new EmployeeDetailsRowMapper(),loginId);
		
		return employeeDetails;
	}

    @Override
	public List<EmployeeDetails> checkEmployee(int jobId){
		
		 return jdbcTemplate.query(CHECK_EMPLOYEE_LIST, new EmployeeDetailsRowMapper(), jobId);
	
		
	}

	@Override
	public boolean updateJobStatus(EmployeeDetails employeeDetails) {
		 Object[]params= {employeeDetails.getProjectDetails().getProjectId(),employeeDetails.getMGR(),employeeDetails.getStatus(),employeeDetails.getEmployeeId()};
				 
			int result =	 jdbcTemplate.update(UPDATE_PROJECT_ID_BY_EMPLOYEE_ID, params);
			 if (result>0) {
				 return true;
			 	
		 }
		return false;
		}

//	@Override
//	public boolean updateAddress(Address address) {
//		 Object[]params= {address.getBuildingName(),
//				           address.getStreet(),
//				           address.getCity(),
//				            address.getPin(),
//				            address.getAddressId()};
//		
//		int result=jdbcTemplate.update(UPDATE_ADDRESS, params);
//		 if (result>0) {
//			 return true;
//		 	
//		 }
//		return false;
	
//	private int EmployeeId;
//	private String Ename;
//	private int Salary;
//	private ProjectDetails projectDetails;
//	private String Designation;
//	private LoginDetails loginDetails;
//    private int MGR;
//	private String Skill1;
//	private String Skill2;
//	private String Skill3;
//	private String Status;
//	}
    


}
